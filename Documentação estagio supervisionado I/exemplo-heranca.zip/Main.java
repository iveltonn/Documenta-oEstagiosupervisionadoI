class Empregado {
    
    
    // exemplo herança do curso linguagem java basico
    
    protected String nome;
    protected String secao;
    protected double salario;

    public Empregado(String nome, String secao, double salario) {
        this.nome = nome;
        this.secao = secao;
        this.salario = salario;
    }

    public void exibirDados() {
        System.out.println("Nome: " + nome);
        System.out.println("Seção: " + secao);
        System.out.println("Salário: R$" + salario);
    }
}

class Gerente extends Empregado {
    private String secretaria;

    public Gerente(String nome, String secao, double salario, String secretaria) {
        super(nome, secao, salario);
        this.secretaria = secretaria;
    }

    public void aumentarSalario(double aumento) {
        salario += aumento + (salario * 0.005);
    }

    public void exibirDados() {
        super.exibirDados();
        System.out.println("Secretária: " + secretaria);
    }
}

