public class HerancaExemplo {
    public static void main(String[] args) {
        Empregado empregado = new Empregado("João", "Departamento A", 2000.0);
        empregado.exibirDados();

        System.out.println();

        Gerente gerente = new Gerente("Maria", "Departamento B", 3000.0, "Ana");
        gerente.exibirDados();
        gerente.aumentarSalario(100.0);
        System.out.println("Após aumento:");
        gerente.exibirDados();
    }
}
