class meuObjeto {

String nome;
int idade, idadenova;
String telefone;


int idadeEmMeses()
{
return (idade * 12);
}

} 
public class Main  {
		public static void main(String[] args) {
		    
  
   meuObjeto amigo = new meuObjeto();
   amigo.nome = "Joao";
   amigo.idade = 33;
   amigo.telefone = "2223311";
   
   
    amigo.idadenova = amigo.idade + 1;
   
   System.out.println ("Idade antiga: \n"+amigo.idade);
   
   System.out.println ("Nova idade: \n"+ amigo.idadenova);
   
   System.out.println ( " a idade em meses é \n " + amigo.idadeEmMeses());

    }
}