public class Calculadora {
    public static int Soma(int a, int b) {
        return a + b;
    }

// exemplo curso linguagem java basico Métodos Estáticos

    public static double Soma(double a, double b) {
        return a + b;
    }

    public static void main(String[] args) {
        int resultadoInt = Soma(3, 5);
        System.out.println("Resultado da soma (int): " + resultadoInt);

        double resultadoDouble = Soma(2.5, 4.7);
        System.out.println("Resultado da soma (double): " + resultadoDouble);
    }
}
