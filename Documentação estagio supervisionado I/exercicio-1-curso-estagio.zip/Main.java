
public class Main
{
    
    
    //exercicio inicial do curso: fazer alteração no "hello word e fazer com que ele imprima o
    //nome completo em 2 linhas
    
	public static void main(String[] args) {
		System.out.println("ivelton jacobina");
		
		System.out.println("ivelton jacobina");
	}
}
